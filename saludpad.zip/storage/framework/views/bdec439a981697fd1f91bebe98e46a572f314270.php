<nav class="navbar navbar-light navbar-expand-lg bg-white shadow"> 
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <?php echo e(config('app.name')); ?>

        </a>
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end  " id="navbarSupportedContent">            
            <ul class="nav nav-pills ">

                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('home')); ?>" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a>
                </li> 
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-document-index')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(setActive('documents.*')); ?>" href="<?php echo e(route('documents.index')); ?>"><?php echo e(__('upload  documents')); ?></a>
                    </li> 
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-document-admin-index')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(setActive('admin.*')); ?>" href="<?php echo e(route('admin.index')); ?>"><?php echo e(__('Descargar documentos')); ?></a>
                </li> 
                <?php endif; ?>
               
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav nav-pills">
                        <a class="nav-link <?php echo e(setActive('login')); ?>" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>                     
                <?php else: ?> 
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>                   
            </ul>           
        </div>
               
    </div>         
</nav>
<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form><?php /**PATH D:\laragon\www\saludpad\resources\views/partials/nav.blade.php ENDPATH**/ ?>