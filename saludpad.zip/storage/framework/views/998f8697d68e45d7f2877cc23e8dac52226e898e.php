

<?php $__env->startSection('title','Saludpad | inicio'); ?>
    

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6">
                <h1 class="display-4 text-primary" >Home Care | PAD</h1>
                <p class="lead secondary">
                   Cuidados en casa. programa de atención domiciliarias 
                </p>              
            </div>
            <div class="col-12 col-lg-6">
                <img class="img-fluid mg-4" src="/img/home.svg" alt="Desarrollo web">
            </div>
            
        </div>
    </div>  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\saludpad\resources\views/home.blade.php ENDPATH**/ ?>