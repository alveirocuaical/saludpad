<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="/js/select2/css/select2.min.css">
    
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <style>
        
    </style>
</head>
<body>

    <div id="app" class="d-flex flex-column h-screen justify-content-between ">
        
        <header>
            <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('partials.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
        
        <main class="py-3">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <footer class="bg-white text-center text-black-50 py-3 shadow">
            <?php echo e(config('app.name')); ?> | Copyright @ <?php echo e(date('Y')); ?>

            
        </footer>
    
    </div>
    <script src="<?php echo e(mix('js/app.js')); ?>" defer=""></script>
    <script src="/js/select2/js/select2.min.js" defer=""></script>
    
</body>
</html><?php /**PATH D:\laragon\www\saludpad\resources\views/layout.blade.php ENDPATH**/ ?>