
<?php if(session('status')): ?>

<div class="alert alert-primary alert-dismissible fade show" role="alert">
    <?php echo e(session('status')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?><?php /**PATH D:\laragon\www\saludpad\resources\views/partials/status.blade.php ENDPATH**/ ?>