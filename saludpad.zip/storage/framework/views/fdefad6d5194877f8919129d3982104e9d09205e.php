

<?php $__env->startSection('title','Saludpad | Administrador'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div>               
                <h1 class="display-5 mb-0"><?php echo e('Documentos '.$titulo); ?></h1> 
            </div>
                  
        </div>
        <p class="lead text-secondary">Limpie la carpeta cuando haya descargado sus archivos!</p> 
        <hr> 
        
        <div class="d-flex flex-wrap justify-content-center align-items-center float-center ">
            <div class="col-12 ">
               
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item">
                           
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"> <?php echo e($documento->nombre); ?></h5>
                                <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($documento->created_at)->diffForHUmans()); ?></small>
                               
                            </div>
                            
                            <p class="mb-1"><?php echo e('Id paciente: ' .$documento->id_paciente); ?></p>
                            <a href="<?php echo e(url('docuno/'.$titulo.'/'.$documento->documento)); ?>"><?php echo e($documento->documento); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <ul class="list-group">
                            <li class="list-group-item">
                                Ningun documento encotrado.
                            </li>
                        </ul>
                    <?php endif; ?>               
                </ul> 
                <div class="d-flex flex-wrap justify-content-between align-items-center float-center">
                    <a href="<?php echo e(url('docs/'.$titulo)); ?>">
                        <button class="btn btn-secondary mt-3" id="final_sub">Descargar todos</button>
                    </a>
                    
                    <form action="<?php echo e(route('admin.destroy', $titulo)); ?>"
                    method="POST"  
                    class="d-inline"
                    onsubmit="return confirm('Esta accion no se puede deshacer, verifique que ha descargado todos los documentos. \n\n ¿está seguro de querer eliminar los archivos de la carpeta?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>

                        <button class="btn btn-sm btn-danger">Eliminar permanentemente</button>
                    </form>

                </div >
               
                
            </div>
              
        </div>
        <div class="mt-4"><?php echo e($documentos->links()); ?></div> 
    </div>  
    
    <script>
       
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\saludpad\resources\views/admin/show.blade.php ENDPATH**/ ?>