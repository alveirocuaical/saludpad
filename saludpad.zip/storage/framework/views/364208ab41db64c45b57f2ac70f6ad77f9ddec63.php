

<?php $__env->startSection('title','Saludpad | Administrador'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div>               
                <h1 class="display-5 mb-0">Pagina no encontrada. </h1>
                <a href="<?php echo e(route('home')); ?>">Volver al inicio</a> 
            </div>        
        </div>
        <hr> 
    </div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\saludpad\resources\views/errors/404.blade.php ENDPATH**/ ?>