<?php

use App\Http\Controllers\DocumentAdminController;
use App\Http\Controllers\DocumentUserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

App::setLocale('es');

Route::view('/','home')->name('home');

Auth::routes(['register' => false]);

Route::resource('documentos',DocumentUserController::class)
                ->names('documents')
                ->parameters(['documentos'=>'service'])
                ;
Route::resource('administrador',DocumentAdminController::class)
                ->names('admin')
                ->parameters(['carpetas'=>'carpeta']);

Route::get('docuno/{titulo}/{documento}',[DocumentAdminController::class,'docDownload']);
Route::get('docs/{titulo}',[DocumentAdminController::class,'zipDownload']);

