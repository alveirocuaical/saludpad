@extends('layout')

@section('title','Saludpad | Administrador')

@section('content')

    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div>               
                <h1 class="display-5 mb-0">Pagina no encontrada. </h1>
                <a href="{{ route('home') }}">Volver al inicio</a> 
            </div>        
        </div>
        <hr> 
    </div>
   
@endsection
