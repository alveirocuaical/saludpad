@extends('layout')

@section('title','Saludpad | inicio')
    

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6">
                <h1 class="display-4 text-primary" >Home Care | PAD</h1>
                <p class="lead secondary">
                   Cuidados en casa. programa de atención domiciliarias 
                </p>              
            </div>
            <div class="col-12 col-lg-6">
                <img class="img-fluid mg-4" src="/img/home.svg" alt="Desarrollo web">
            </div>
            
        </div>
    </div>  
    
@endsection